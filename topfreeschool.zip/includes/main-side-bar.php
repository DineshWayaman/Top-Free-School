<input type="search" width="100%" class="form-control" name="" id="" placeholder="Search">
        

            <div class="m-2 shadow">
                <img src="http://i.imgur.com/sDLIAZD.png" width="100%" style="height: 300px;" alt="" srcset="">
          </div>

          <hr>

            <div class="p-2">
                <div class="row">
                    <div class="col-md-4">
                         <img src="http://i.imgur.com/sDLIAZD.png" style="height: 70px; min-width: 100%; max-width: 100%;" alt="">
                    </div>
                    <div class="col-md-8">
                    <a href="" class="side-a"><p class="m-0 two-lines" style="font-weight: bold;">Lorem ipsum dolor sit amet</p></a>
                    <p style="font-size: 13px;  color: rgb(26, 25, 25);">2022-02-09</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                         <img src="https://aqwamag.com/wp-content/uploads/2021/08/featured-image-1536x1090.png" style="height: 70px; min-width: 100%; max-width: 100%;" alt="">
                    </div>
                    <div class="col-md-8">
                    <p class="m-0 two-lines" style="font-weight: bold;">Lorem ipsum dolor sit amet</p>
                    <p style="font-size: 13px;  color: rgb(26, 25, 25);">2022-02-09</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                         <img src="http://i.imgur.com/sDLIAZD.png" style="height: 70px; min-width: 100%; max-width: 100%;" alt="">
                    </div>
                    <div class="col-md-8">
                    <p class="m-0 two-lines" style="font-weight: bold;">Lorem ipsum dolor sit amet</p>
                    <p style="font-size: 13px;  color: rgb(26, 25, 25);">2022-02-09</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                         <img src="http://i.imgur.com/sDLIAZD.png" style="height: 70px; min-width: 100%; max-width: 100%;" alt="">
                    </div>
                    <div class="col-md-8">
                    <p class="m-0 two-lines" style="font-weight: bold;">Lorem ipsum dolor sit amet</p>
                    <p style="font-size: 13px;  color: rgb(26, 25, 25);">2022-02-09</p>
                    </div>
                </div>
            </div>
            <!-- <div class="input-group">
            <input class="form-control border-end-0 border rounded-pill" type="text" value="search" id="example-search-input">
            <span class="input-group-append">
                <button class="btn btn-outline-secondary bg-white border-start-0 border rounded-pill ms-n3" type="button">
                    <i class="fa fa-search"></i>
                </button>
            </span>
          </div> -->
          <hr>

          <div class="mt-2">
              <h5>Categories</h5>
              <ul>
                  <li><a href="" class="side-a">Mobile App Development</a></li>
                  <li><a href="" class="side-a">Web Development</a></li>
                  <li><a href="" class="side-a">Tech Update</a></li>
              </ul>
          </div>

        