<meta name="description" content="<?php echo $postfetch['p_desc'] ?>">
<meta name="referrer" content="no-referrer-when-downgrade">
<meta name="robots" content="all">
<meta content="en_US" property="og:locale">
<meta content="TopFreeSchool" property="og:site_name">
<meta content="Home" property="og:type">
<meta content="https://topfreeschool.com/" property="og:url">
<!-- should use -->
<meta content="Top Free School : Home" property="og:title">
<meta content="<?php echo $postfetch['p_desc'] ?>" property="og:description">
<meta name="keywords" content="<?php echo $postfetch['p_keywords'] ?>">
  <meta name="author" content="John Doe">
<!-- Image -->
<meta content="<?php echo $postfetch['p_feature_img'] ?>" property="og:image">
<link href="https://topfreeschool.com/" rel="home">