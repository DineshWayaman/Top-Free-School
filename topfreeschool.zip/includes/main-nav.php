<nav class="navbar navbar-expand-lg navbar-light bg-light phone-new-pad text-uppercase">
  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
    <a href="index.php" class="navbar-brand"><img src="img/logo.png" alt="" style="width: 50px; height: 45px;"></a>
  <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Catagories
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="#">Technology</a>
          <a class="dropdown-item" href="#">Development</a>
          <a class="dropdown-item" href="#">News</a>

        </div>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="blogs.php">About Us</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="#">Contact Us</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Privacy Policy</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Disclaimer</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Terms and Condition</a>
      </li>
    </ul>
  </div>




</nav>